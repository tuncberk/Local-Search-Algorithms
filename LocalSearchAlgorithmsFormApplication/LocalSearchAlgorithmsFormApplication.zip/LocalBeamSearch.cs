﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//maybe don't pass Queen[] queens as reference...................
namespace LocalSearchAlgorithmsFormApplication
{
    class LocalBeamSearch
    {
        Queen[] queens = new Queen[10];
        int states;
        int gridSize;

        public LocalBeamSearch(int gridSize, Queen[] queens, int states)
        {
            this.gridSize = gridSize;
            this.queens = queens;
            this.states = states;
        }
        public Queen[] localBeamSearchAlgorithm()
        {
            List<Queen[]> statesArray = new List<Queen[]>();

            //List<List<int>> heuristicArray = new List<List<int>>();



            Random rand = new Random();


            for (int i = 0; i < states; i++)   //for each state
            {

                Queen[] queenArray = new Queen[gridSize];
                for (int k = 0; k < gridSize; k++)
                {
                    int row = rand.Next(0, gridSize);
                    Queen q = new Queen(k, row);
                    queenArray[k] = q;
                    queens[k] = q;
                    //queenArray[k].setY(row);

                    // h += heuristic.calculateHeuristic(queenArray[k]);
                }


                //heuristicArray.Add(heuristics);
                statesArray.Add(queenArray);
                //h = 0;
            }
            queens = findSolution(statesArray);




            //looooooooooooop


            return queens;
        }
        public Queen[] findSolution(List<Queen[]> statesArray)
        {
            
            Heuristic heuristic = new Heuristic(queens, gridSize);
            List<int> heuristics = new List<int>();
            List<Queen[]> statesArraySorted = new List<Queen[]>(states);
            List<int> heuristicsCopy = new List<int>(states);

            statesArraySorted = sortQueens(statesArray, statesArraySorted, heuristics, heuristicsCopy);
            for (int k = 0; k < 2; k++) //for each desired number of elected states.
            {
                for (int i = 0; i < statesArray.Count; i++)
                {
                    int h = 0;
                    for (int j = 0; j < gridSize; j++)
                    {
                        queens[j] = statesArray[i][j];
                        h += heuristic.calculateHeuristic(queens[j]);
                    }
                    heuristics.Add(h);
                }
            }
            return queens;
        }
        public List<Queen[]> sortQueens(List<Queen[]> statesArray, List<Queen[]> statesArraySorted, List<int> heuristics, List<int> heuristicsCopy)
        {
            for (int i = 0; i < statesArray.Count; i++)
            {
                statesArraySorted.Add(statesArray[i]);
            }

            // statesArraySorted = statesArray;
            for (int i = 0; i < heuristics.Count; i++)
            {
                heuristicsCopy.Add(heuristics[i]);
            }
            //heuristicsCopy = heuristics;
            heuristics.Sort();

            for (int i = 0; i < heuristicsCopy.Count; i++)
            {
                for (int j = 0; j < heuristics.Count; j++)
                {
                    if (heuristicsCopy[i] == heuristics[j])
                    {
                        int temp = j;
                        while (temp < heuristics.Count && statesArraySorted[j] != statesArray[i])
                        {
                            temp++;
                            //j++;
                        }
                        statesArraySorted[j] = statesArray[i];
                    }
                }
            }

            return statesArraySorted;
        }

        //public static List<T> DeepClone<T>(this List<T> items)
        //{
        //    var query = from T item in items select item.DeepClone();
        //    return new List<T>(query);
        //}
    }
}
